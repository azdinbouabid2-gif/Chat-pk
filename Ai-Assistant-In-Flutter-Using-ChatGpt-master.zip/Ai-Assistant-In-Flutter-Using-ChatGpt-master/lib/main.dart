import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';

import 'apis/app_write.dart';
import 'helper/ad_helper.dart';
import 'helper/global.dart';
import 'helper/pref.dart';
import 'screen/splash_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // init hive
  await Pref.initialize();

  // for app write initialization
  AppWrite.init();

  // for initializing facebook ads sdk
  AdHelper.init();

  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  await SystemChrome.setPreferredOrientations(
      [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: appName,
      debugShowCheckedModeBanner: false,

      themeMode: Pref.defaultTheme,

      //dark
      darkTheme: ThemeData.dark().copyWith(
  scaffoldBackgroundColor: const Color(0xFF101010),
  primaryColor: const Color(0xFFFFD700),
  appBarTheme: const AppBarTheme(
    backgroundColor: Color(0xFF1E1E1E),
    foregroundColor: Color(0xFFFFD700),
    centerTitle: true,
    elevation: 1,
    titleTextStyle: TextStyle(
      color: Color(0xFFFFD700),
      fontSize: 20,
      theme: ThemeData.light().copyWith(
  scaffoldBackgroundColor: const Color(0xFFF8F9FA),
  primaryColor: const Color(0xFFFFD700),
  appBarTheme: const AppBarTheme(
    backgroundColor: Colors.white,
    foregroundColor: Colors.black,
    centerTitle: true,
    elevation: 1,
    titleTextStyle: TextStyle(
      color: Colors.black,
      fontSize: 20,
      fontWeight: FontWeight.w500,
    ),
  ),
),

      
      extension ThemeOnThemeData on ThemeData {
  Color get lightTextColor =>
      this == Brightness.dark ? Colors.white70 : Colors.black54;

  Color get buttonColor => const Color(0xFFFFD700); // لون ذهبي للأزرار والروابط
}

}